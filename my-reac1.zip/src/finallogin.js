import React from 'react';
import axios from 'axios';
import FooterPage from './footer'
import { MDBContainer, MDBMask, MDBView,MDBRow,MDBCol,MDBCard, MDBCardBody,MDBModalFooter,MDBIcon,MDBCardHeader,MDBBtn} from "mdbreact";

class FullPageIntroWithNonFixedTransparentNavbar extends React.Component {
  constructor(props){
    super(props);
  
  this.state = {
    username:'',
    password: ''
  
 };
  }
  validateForm(e) {
    this.newLogin={
        username:this.state.username,
        password:this.state.password 
      }
        
       
        
         axios.post("http://localhost:9800/student/login",this.newLogin).then(
            
             res=>{
                //  this.setState({[res.data]:this.Login})
                console.log(this.newLogin); 
                console.log(res.data);   
                if(res.data==1)
                {
                
      
                let path='/create';
                 this.props.history.push(path);
                alert("Logged In Successfully");
      
              }
      
              else
              {
                  alert("error logging in");
              }
            }) 
            }
   // return this.state.email.length > 0 && this.state.password.length > 0;
  
  handleName (event){
    this.setState({
      username: event.target.value
    });
    console.log(this.state.username);
  }
  handlePassword(event) {
    this.setState({
      password: event.target.value
    });
    console.log(this.state.password);
  }

  handleSubmit = event => {
    event.preventDefault();
  }


  render() {
    return (
      
        <div>
<MDBView src="https://mdbootstrap.com/img/Photos/Others/img%20(50).jpg" >
            

            <MDBMask overlay="indigo-slight" className="flex-center flex-column text-white text-center">
            <MDBContainer>

                <br></br>
            <MDBRow style={{marginTop:"5%"}}>
        <MDBCol md="4"></MDBCol>
        <MDBCol md="4">
         
        
          <MDBCard>
            <MDBCardBody>
            <form onSubmit={this.handleSubmit} method="post">

              <MDBCardHeader className="form-header deep-blue-gradient rounded">
                <h3 className="my-3">
                  <MDBIcon icon="lock" /> Login:
                </h3>
              </MDBCardHeader>
              <br></br>
              <label
                htmlFor="defaultFormEmailEx"
                className="black-text font-weight-light"
                
              >
                Your Username
              </label>
              <input
                type="email"
                id="defaultFormEmailEx"
                className="form-control"
                value={this.state.username}
                onChange={(e)=>this.handleName(e)}
  
              />

              <label
                htmlFor="defaultFormPasswordEx"
                className="black-text font-weight-light"
              >
                Your password
              </label>
              <input
                type="password"
                id="defaultFormPasswordEx"
                className="form-control"
                value={this.state.password}
                onChange={(e)=>this.handlePassword(e)}
  
              />

              <div className="text-center mt-4">
                <MDBBtn color="light-blue" className="mb-3" onClick={()=>this.validateForm()}
            type="submit"
>
                  Login
                </MDBBtn>

               
              </div>
              </form>

              <MDBModalFooter>
                <div className="font-weight-light">
                  <p style={{color:"black"}}>Not a member? Sign Up</p>
                  <p style={{color:"black"}}>Forgot Password?</p>
                </div>
              </MDBModalFooter>
            </MDBCardBody>
          </MDBCard>
        </MDBCol>
 
        
        
        <MDBCol md="4"></MDBCol>
      </MDBRow>
      
       
    
    </MDBContainer>
    
            </MDBMask>
            
          </MDBView>
          
          
         {/* <FooterPage></FooterPage> */}
      
        </div>
          
     

        
          
           
           
        
      
    );
  }
}

export default FullPageIntroWithNonFixedTransparentNavbar;