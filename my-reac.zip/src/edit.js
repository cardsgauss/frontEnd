import React from 'react';
import axios from 'axios';
import Editing from './editInfo';
import { Container } from '@material-ui/core';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import bg from './b.jpg';
import NavbarPage from './newnav';
class Edit extends React.Component {
    constructor(props) {
        super(props);
        this.state = { ...Editing.obj };
        
    }
    handleName = (event) => {
        this.setState({ name: event.target.value })}

        handleEmail = (event) => {
            this.setState({ email: event.target.value });
        }
        handleMobile = (e) => {
            this.setState({ mobile: e.target.value });
        }
        handleProduct = (e) => {
            this.setState({ product: e.target.value });
        }
        handleAadhaar = (e) => {
            this.setState({ aadhaar: e.target.value });
        }
        handleAp = (e) => {
            this.setState({ address: e.target.value });
        }
        handleIncome = (e) => {
            this.setState({ income: e.target.value });
        }
        handleDate = (e) => {
            this.setState({ dob: e.target.value });
        }

        onSubmit = (e) => {
           
            e.preventDefault();

            axios.put(`http://localhost:9000/customer/update`, this.state)
                .then(res => {

                    if (res.data > 0) {
                        alert("Updated Successfully");
                        { this.setState({ [res.data]: this.customer }) };
                        let path = '/home';
                        this.props.history.push(path);
                    } else {
                        alert("Error updating Customer");
                    }
                })

        }
        render() {
           
            return (
                <div>
                    <NavbarPage/>
                <div style={{backgroundImage:"url("+bg +")",backgroundSize:'cover'}}>
                <Paper style={{ marginLeft: "15%", marginRight: "15%", marginTop: "-4%" }}>
                    <Container maxWidth="xl" style={{ marginTop: "5%" }}>
                        <Grid>
                            <form onSubmit={this.onSubmit} >

                                <div className="row">

                                    <div className="col-sm-12" >
                                        <h2 style={{ alignContent: 'center', textAlign: 'center', marginTop: "4%" }}>Edit Application</h2>

                                        <br></br>
                                        <h5 className="text-center" style={{ fontWeight: '600' }} > Form Creation</h5>
                                        <br></br>

                                        <form className="form-horizontal" className="col-sm-12" style={{ paddingLeft: "25%" }}  >
                                            <div className="form-group">
                                                <label className="control-label col-sm-8" >Name:</label>
                                                <div className="col-sm-8">
                                                    <input type="text" className="form-control" id="name" title="Enter only letters like Jack" value={this.state.name} onChange={(e) => this.handleName(e)}
                                                        placeholder="Enter name" required
                                                    />
                                                </div>
                                            </div>
                                            <div className="form-group">
                                                <label className="control-label col-sm-8" >Email:</label>
                                                <div className="col-sm-8">
                                                    <input type="email" required className="form-control" id="email" placeholder="Enter email" name="email" value={this.state.email}
                                                        onChange={(e) => this.handleEmail(e)} />
                                                </div>
                                            </div>
                                            <div className="form-group">
                                                <label className="control-label col-sm-8" >Mobile No:</label>
                                                <div className="col-sm-8">
                                                    <input type="text" required maxLength="10" pattern="([0-9\s]){10,}" title="Enter 10 digit mobile no." className="form-control" id="phone" placeholder="Enter mobile no" name="phone" value={this.state.mobile}
                                                        onChange={(e) => this.handleMobile(e)} />
                                                </div>
                                            </div>
                                            <div className="form-group">
                                                <label className="control-label col-sm-8" >Date of Birth:</label>
                                                <div className="col-sm-8">
                                                    <input type="date" className="form-control" id="dob" placeholder="Enter dob" name="dob"
                                                        onChange={this.handleDate} value={this.state.dob} max="1998-12-31" required />
                                                </div>
                                            </div>
                                            <div className="form-group">
                                                <label className="control-label col-sm-8" >Product:</label>
                                                <div className="col-sm-8">

                                                    <select className="form-control" id="product" onChange={(e) => this.handleProduct(e)} value={this.product}>
                                                        <option>Please select Card Type</option>
                                                        <option>Silver</option>
                                                        <option>Gold</option>
                                                        <option>Platinum</option>

                                                    </select>

                                                </div>
                                            </div>
                                            <div className="form-group">
                                                <label className="control-label col-sm-8" >Aadhaar Card No:</label>
                                                <div className="col-sm-8">
                                                    <input type="text" required maxLength="12" pattern="([0-9\s]){12,}" title="Enter 12 digit aadhaar no." className="form-control" id="aadhaar" value={this.state.aadhaar} onChange={(e) => this.handleAadhaar(e)} placeholder="Enter aadhaar no" name="aadhaar"

                                                    />
                                                </div>
                                               

                                            </div>
                                            <div className="form-group">
                                                <label className="control-label col-sm-8" >Address proof:</label>
                                                <div className="col-sm-8">
                                                    <input type="text" className="form-control" required
                                                        value={this.state.address} placeholder="Enter Id proof no" name="ap"
                                                        onChange={(e) => this.handleAp(e)} />
                                                </div>
                                              

                                            </div>
                                            <div className="form-group">
                                                <label className="control-label col-sm-8" >Income proof:</label>
                                                <div className="col-sm-8">
                                                    <input type="text" required className="form-control" maxLength="10" title="Enter 10 digit pan no." pattern="([A-z0-9À-ž\s]+){10,}" id="ip" placeholder="Enter pan card no" name="ip" value={this.state.income} onChange={(e) => this.handleIncome(e)} placeholder="Enter pan card no" name="ip" />
                                                </div>
                                                

                                            </div>
                                           
                                            <div>

                                            </div>

                                            <div className="but-al">

                                                <div className="form-group">
                                                    <div className=" col-sm-8 col-sm-offset-6">
                                                        <button type="submit" className="btn btn-success"  >Submit</button>


                                                        <button type="reset" className=" col-sm-offset-2" className="btn btn-primary">Reset</button>
                                                    </div>

                                                </div>
                                            </div>
                                        </form>

                                    </div>

                                </div>

                            </form>
                        </Grid>

                    </Container>
                </Paper>
</div>
</div>
            );
        }
    }

    export default Edit;



