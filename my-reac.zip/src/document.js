import React, { Component } from 'react';
import './App.css';
import ReactTable from "react-table";
import "react-table/react-table.css";
import MaterialTable from 'material-table';
import { style } from '@material-ui/system';
import PostCustomer from './PostCustomer';
import {BrowserRouter as Router,Switch,Link,Route} from "react-router-dom";
import axios from 'axios';
import List from './list';
import editing from './editInfo';
import bg from './bg1.jpeg';
class DocumentVerification extends Component {
  constructor(props) {
    super(props);
    this.state = {
      posts: []
      
    }

  }

  componentDidMount() {
    const url = "http://localhost:9000/customer/";
    fetch(url, {
      method: "GET"
    }).then(reponse => reponse.json()).then(posts => {
      this.setState({ posts, posts })
    })
  }
//   deleteRow(id){
//       console.log("id",id)
//   }
 deleteRow = (id) => {
     console.log(id)
    
     axios.delete("http://localhost:9000/app/delete/"+encodeURIComponent(id))
    .then(
        /*axios.get("http://localhost:9122/customer/")
        .then((res) => {
            console.log(res.data);
            this.setState({
                posts: res.data
            })
        })*/

       alert("Deleted Successfully")

        //this.forceUpdate()
         /*fetch("http://localhost:9122/customer/", {
            method: "GET"
          }).then(reponse => reponse.json()).then(posts => {
            this.setState({ posts, posts })
          })*/
       
     );
}
editRow=(id)=>{
    console.log(id);
   
    axios.get("http://localhost:9000/customer/"+encodeURIComponent(id))
    .then((res) => {
        //console.log(res.data);
        editing.obj=res.data;
        let path = 'list';
    this.props.history.push(path);
    });
}
createRow=()=>{
   
    let path = 'form';
    this.props.history.push(path);
    
}
NextPage=()=>{
   
    let path = 'final';
    this.props.history.push(path);
    
}
  render() {
      
    const columns = [
      {
        Header: "Customer id",
        accessor: "id",
        width:150,maxWidth:100,minWidth:100

      },
      {
        Header: "Customer name",
        accessor: "name"
      },
      {
        Header: "Verification by Supervisior",
        accessor: "sup_verification",
        
        
      }
        ,   
      {
        Header: "Actions",
        Cell:props=>{
            return(
                [
                    
                   
        <button className="btn btn-success"  style={{marginLeft:10}} onClick={()=>{
            this.NextPage();}}>Next</button>
               
              
                
                ]
            )
        }
      }
    ]
    return (
     <div>
             {/* <ul>
        
        <li>
          <Link to="/list" >EDIT</Link>
        </li>
        <li>
          <Link to="/form" >CREATE</Link>
          
        </li>
      </ul> */}
      <div style={{textAlign:"center",marginTop:-40,marginBottom:20}}>
    <h1>Document Verification</h1>
</div>
      <ReactTable
      
        columns={columns}
        
        data={this.state.posts}
       defaultPageSize={5}
    
      >
      </ReactTable>
      </div>
      
    );
  }
}

export default DocumentVerification;
