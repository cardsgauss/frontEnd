import React from 'react';
import Grid from '@material-ui/core/Grid';
import Container from '@material-ui/core/Container';
import Paper from '@material-ui/core/Paper';
import bg from './bg1.jpeg';
import Editing from './editInfo';
import axios from 'axios';
class Final extends React.Component {
    constructor(props){
        super(props);
        this.state = { ...Editing.obj };
       
        console.log(this.state);
    }
    handleProduct = (event) => {
         event.preventDefault();
 
        axios.post(`http://localhost:9000/customer/prod`,this.state)
        .then(res => {

            if (res.data > 0) {
                alert("Credit Card Generated Successfully");
                axios.put("http://localhost:9000/app/updatestat/"+encodeURIComponent(this.state.id))
                .then((res) => {
                    //console.log(res.data);
                   // editing.obj=res.data;
                 
                    let path = 'home';
                this.props.history.push(path);
                  
                });
                
            } else {
                alert("Error generating credit card");
            }
        })
    }
    render(){
        return (
            <div style={{backgroundImage:"url("+bg +")",backgroundSize:'cover'}}>
            <Container maxWidth="xl">
            <Paper style={{ marginLeft: "25%", marginRight: "25%", marginTop: "12%" }}>
            

                <div className="text-center">
                   
                            <strong ><h2 style={{ textAlign: 'center',paddingTop:"7%"}}>Congratulations!!!</h2></strong>
                        
                        <form style={{ padding: '20px' }}>
                        <div>
                        <p  >Your Credit Card has been generated.<br></br>
                                
                                </p>
                                
                        </div>
                          <div>
                          <h5 >Send Email to Customer:</h5>
                          <button type= "default" >Send</button>
                          </div>
                        <br></br>
                        <div>
                        <h5 >Send card to TP system for Printing:</h5>
                        <button onClick={this.handleProduct} >Send</button>
                        </div>
                        
                       
                        <br></br>
                        <br></br>
                        </form>
                    
               
            </div>

            </Paper>
            
            </Container>
</div>
        );

    }
}export default Final;

