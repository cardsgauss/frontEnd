import React from 'react';
import Container from '@material-ui/core/Container'
import Paper from '@material-ui/core/Paper'
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import Editing from './editInfo';
import bg from './b.jpg';
import axios from 'axios';
import NavbarPage from './newnav';

class Approval extends React.Component {
    constructor(props){
        super(props);
        this.state={...Editing.obj};
    }
    handleAppeal=()=>{
        let path='appeal';
        this.props.history.push(path);
    }
    handleDoc=()=>{
        axios.put(`http://localhost:9000/customer/docstatus`,   this.state )
                .then(res1=>{
                    {
                    let path='document'
                this.props.history.push(path)}
                
                    })
        
    }
    render() {
        
        return (
            <div>
                <NavbarPage/>
            <div style={{backgroundImage:"url("+bg +")",backgroundSize:'cover'}}>
            <Container>
                <Paper style={{ marginLeft: "15%", marginRight: "15%", paddingTop:10 }}>
                <div className="text-center "   >
           
           <h1 style={{paddingTop:25}}>CUSTOMER VERIFICATION</h1>

           <form className="form-horizontal" style={{ marginBottom:"5%"}} >
           <div style={{ marginLeft:"30%"}}>
                                <div style={{paddingTop:25}} className="form-group">
                                    <h6 className="col-md-6 ">Customer id</h6>
                                    <div className="col-md-6">
                                        <input type="text" className="form-control" id="inputAppid" value={this.state.id} placeholder="Application id" />
                                    </div>
                                    </div>
                                <div className="form-group">
                                    <h6 className="col-md-6 ">Customer name:</h6>
                                    <div className="col-md-6">
                                        <input type="text" className="form-control" id="inputName" value={this.state.name} placeholder="Applicant name" />
                                    </div>
                                </div>

                                <div>
                                </div>
                                
      <ExpansionPanel  useState="panel1" className="col-sm-6 " onChange={panel => (event, newExpanded) => {
    React.useState('panel1')(newExpanded ? panel : false);}} >
        <ExpansionPanelSummary aria-controls="panel1d-content" id="panel1d-header">
          <Typography><h6>Appeal Section</h6></Typography>
        </ExpansionPanelSummary>
        <ExpansionPanelDetails>
          <Typography>
            Proceed to Appeal Section to change Credit Limit.
            <div>

            <input id="appeal" type="button" onClick={this.handleAppeal} value="Appeal" className="btn btn-danger" />
            </div>
          </Typography>
        </ExpansionPanelDetails>
      </ExpansionPanel>
      <ExpansionPanel useSta="panel2" className="col-sm-6 " onChange={panel => (event, newExpanded) => {
    React.useState('panel2')(newExpanded ? panel : false);}}>
        <ExpansionPanelSummary aria-controls="panel2d-content" id="panel2d-header">
          <Typography><h6>Documents Verification</h6></Typography>
        </ExpansionPanelSummary>
        <ExpansionPanelDetails>
          <Typography>
            Proceed towards Documents Verification on customer approval.
            <div>
            <input id="dd" type="button" value="Next" onClick={this.handleDoc}  className="btn btn-success" />
            </div>
            
          </Typography>
        </ExpansionPanelDetails>
      </ExpansionPanel>
      
    
                                </div>
                                </form>

                                <br></br>

           

               </div>
                </Paper>
                
               </Container>
        
           
                    </div>
                    </div>
            
        );
    }
};
export default Approval;

