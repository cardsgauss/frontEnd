import React from 'react';
//import './App.css';
import { Container } from '@material-ui/core';
import Paper from '@material-ui/core/Paper';
import Editing from './editInfo';
import bg from './bg1.jpeg';
class CreditScore extends React.Component {
    constructor(props){
        super(props);
        this.state={...Editing.obj,credit:'',limit:''};
        console.log(this.state);
        //this.temp = this.state;
    }
    handleCredit=()=>{
        this.setState({credit:this.state.score})
        var limit;
    if(this.state.score>=500 && this.state.score<550){
        limit=15000;
    }
    if(this.state.score>=550 && this.state.score<600){
         limit=25000;
        }
        if(this.state.score>=600 && this.state.score<650){
             limit=35000;
            }
            if(this.state.score>=650 && this.state.score<700){
                 limit=45000;
                }
                if(this.state.score>=700 && this.state.score<750){
                     limit=55000;
                    }
                    if(this.state.score>=750 && this.state.score<800){
                        limit=70000;
                        }
                        if(this.state.score>=800 && this.state.score<850){
                            limit=90000;
                            }
                            if(this.state.score>=850 && this.state.score<900){
                                 limit=150000;
                                }
    this.setState({limit:limit})
    }
    NextPage=()=>{
        //console.log(id);
       
        let path = 'approval';
    this.props.history.push(path);
     }
    render() {
        return (

            
<div style={{backgroundImage:"url("+bg +")",backgroundSize:'cover'}}>
            
            <Paper style={{ marginLeft: "15%", marginRight: "15%", marginTop: "3%" }}>
            <br></br>
                <Container maxWidth="xl" style={{ marginTop: "5%", marginBottom:"10%" }}>
                
                

                        <div id="header" className="text-center">
                            <h2 style={{ alignContent: 'center', textAlign: 'center', marginTop: "10%" }}>Generate Credit Score of Customer</h2>
                            <p>Credit limit of customer will be dependant on the CIBIL score. <u>Please confirm details to proceed.</u></p>
                        </div>
                        
                        <div id="filledform" style={{ paddingTop: "5%" }} >
                            <form className="form-horizontal" style={{marginLeft:"30%"}} >
                                <div className="form-group">
                                    <h6 className="col-md-5 control-label">Customer id</h6>
                                    <div className="col-md-6">
                                        <input type="text" className="form-control" id="inputAppid" value={this.state.id} placeholder="Application id" />
                                    </div>
                                </div>
                                <div className="form-group">
                                    <h6 className="col-md-5 control-label">Customer name</h6>
                                    <div className="col-md-6">
                                        <input type="text" className="form-control" id="inputName" value={this.state.name} placeholder="Applicant name" />
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="col-md-offset-5 col-md-4">
                                        <div className="checkbox">
                                            <label>
                                                <input type="checkbox" />Confirm
                                    </label>
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="col-md-offset-5 col-md-5">
                                        <button type="button" className="btn btn-default" onClick={this.handleCredit}>Generate Score</button>
                                    </div>
                                </div>

                                <div className="form-group">

                                    <h6 className="col-md-5 control-label">Credit Score</h6>
                                    <div className="col-md-6">
                                        <input className="form-control" type="text" value={this.state.credit} placeholder="Readonly CREDIT SCORE" readOnly />
                                    </div>
                                </div>
                                <div className="form-group">

                                    <h6 className="col-md-5 control-label">Credit Limit</h6>
                                    <div className="col-md-6"> <input className="form-control" type="text" value={this.state.limit} placeholder="Readonly CREDIT LIMIT"
                                        readOnly />
                                    </div>
                                </div>
                                <div className="form-group">
                                    <div className="col-md-offset-5 col-md-5">
                                        
                                        <button  type="button" className="btn btn-success" style={{marginLeft:10}} onClick={()=>{
            this.NextPage();}}>Next</button>
                                    </div>
                                    <br>
                                    </br>
                                    <br>
                                    </br>

                                </div>


                            </form>


                        </div>

                    
                
            
            </Container>
            </Paper>
            
</div>
        )

    }
}
export default CreditScore