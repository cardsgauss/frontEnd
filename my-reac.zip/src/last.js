import React from 'react';
import Grid from '@material-ui/core/Grid';
import Container from '@material-ui/core/Container';
import Paper from '@material-ui/core/Paper';
import bg from './bg1.jpeg';
class Final extends React.Component {
    render(){
        return (
            <div style={{backgroundImage:"url("+bg +")",backgroundSize:'cover'}}>
            <Container maxWidth="xl">
            <Paper style={{ marginLeft: "25%", marginRight: "25%", marginTop: "12%" }}>
            

                <div className="text-center">
                   
                            <strong ><h2 style={{ textAlign: 'center',paddingTop:"7%"}}>Congratulations!!!</h2></strong>
                        
                        <form style={{ padding: '20px' }}>
                        <div>
                        <p  >Your Credit Card has been generated.<br></br>
                                
                                </p>
                                
                        </div>
                          <div>
                          <h5 >Send Email to Customer:</h5>
                          <button type= "default" >Send</button>
                          </div>
                        <br></br>
                        <div>
                        <h5 >Send card to TP system for Printing:</h5>
                        <button type= "default" >Send</button>
                        </div>
                        
                       
                        <br></br>
                        <br></br>
                        </form>
                    
               
            </div>

            </Paper>
            
            </Container>
</div>
        );

    }
}export default Final;

