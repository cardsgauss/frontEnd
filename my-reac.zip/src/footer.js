import React from "react";
import { MDBCol, MDBContainer, MDBRow, MDBFooter } from "mdbreact";

const FooterPage = () => {
  return (
    <MDBFooter color="indigo" className="page-footer font-small pt-0">
      <div style={{ backgroundColor: "darkblue" }}>
        <MDBContainer fluid className="text-center text-md-left">
          <MDBRow className="py-4 d-flex align-items-center">
            <MDBCol md="6" lg="5" className="text-center text-md-left mb-4 mb-md-0">
              <h6 className="mb-0 white-text">
                Get connected with us on social networks!
              </h6>
            </MDBCol>
            <MDBCol md="6" lg="7" className="text-center text-md-right">
              <a className="fb-ic ml-0" href="https://www.facebook.com/StandardCharteredIN/">
                <i className="fab fa-facebook-f white-text mr-lg-4"> </i>
              </a>
              <a className="tw-ic" href="https://twitter.com/StanChartIN">
                <i className="fab fa-twitter white-text mr-lg-4"> </i>
              </a>
              <a className="gplus-ic" href="https://www.sc.com/uk/fresh-start.html">
                <i className="fab fa-google-plus-g white-text mr-lg-4"> </i>
              </a>
              <a className="li-ic" href="https://www.linkedin.com/company/standardchartered/">
                <i className="fab fa-linkedin-in white-text mr-lg-4"> </i>
              </a>
              <a className="ins-ic" href="https://www.instagram.com/stanchart/">
                <i className="fab fa-instagram white-text mr-lg-4"> </i>
              </a>
            </MDBCol>
          </MDBRow>
        </MDBContainer>
      </div>
      <MDBContainer className="mt-6 mb-4 text-center text-md-left">
        <MDBRow className="mt-3">
          <MDBCol md="5" lg="5" xl="6" className="mb-6">
            <h6 className="text-uppercase font-weight-bold">
              <strong>Company name</strong>
            </h6>
            <hr className="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style={{ width: "60px" }} />
            <p>
            Standard Chartered Bank is India’s largest international bank with 100 branches in 43 cities, and we have been operating here since 1858. Key clients segments include Corporate & Institutional Banking as well as Retail Banking. 
            </p>
          </MDBCol>
          <MDBCol md="4" lg="4" xl="2" className="mb-4">
            <h6 className="text-uppercase font-weight-bold">
              <strong>Products</strong>
            </h6>
            <hr className="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style={{ width: "60px" }} />
            <p>
              <a href="/home">Credit Cards</a>
            </p>
            <p>
              <a href="#!">Loans</a>
            </p>
            <p>
              <a href="#!">Liquidity</a>
            </p>
            <p>
              <a href="#!">Payments</a>
            </p>
          </MDBCol>
          <MDBCol md="4" lg="4" xl="2" className="mb-4">
            <h6 className="text-uppercase font-weight-bold">
              <strong>Useful links</strong>
            </h6>
            <hr className="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style={{ width: "60px" }} />
            <p>
              <a href="https://www.sc.com/in/bank-with-us/">Bank With Us</a>
            </p>
            <p>
              <a href="https://www.sc.com/in/help/">Get Help</a>
            </p>
            <p>
              <a href="https://www.sc.com/in/about-us/">About Us</a>
            </p>
            <p>
              <a href="https://www.sc.com/en/privacy-policy/">Privacy Policy</a>
            </p>
          </MDBCol>
          <MDBCol md="4" lg="3" xl="2" className="mb-4">
            <h6 className="text-uppercase font-weight-bold">
              <strong>Website</strong>
            </h6>
            <hr className="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style={{ width: "60px" }} />
            <p>
              <a href="https://www.sc.com/in/news-media/"> News and Media</a>
            </p>
            <p>
            <a href="https://www.sc.com/en/banking/banking-for-companies/global-research/"> Global Research </a>
            </p>
            <p>
            <a href="https://www.sc.com/en/careers"> Careers </a>
            </p>
            <p>
            <a href="https://www.sc.com/en/our-locations/"> Worldwide Locations </a>
            </p>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
      <div className="footer-copyright text-center py-3">
        <MDBContainer fluid>
          &copy; {new Date().getFullYear()} Copyright: <a href="https://www.sc.com"> StandardChartered.com </a>
        </MDBContainer>
      </div>
    </MDBFooter>
  );
}

export default FooterPage;

