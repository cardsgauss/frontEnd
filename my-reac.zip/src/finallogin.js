import React from 'react';
import axios from 'axios';
import { MDBContainer, MDBMask, MDBView,MDBRow,MDBCol,MDBCard, MDBCardBody,MDBModalFooter,MDBIcon,MDBCardHeader,MDBBtn} from "mdbreact";
import Editing from './editInfo';
class LoginPage extends React.Component {
  constructor(props){
    super(props);
  
  this.state = {
    username:'',
    password: ''
  
 };
  }
  validateForm(e) {
    this.newLogin={
        username:this.state.username,
        password:this.state.password 
      }
        
       
        
         axios.post("http://localhost:9000/student/login",this.newLogin).then(
            
             res=>{
                
               localStorage.setItem("id",this.newLogin.username)
                if(res.data==1)
                {
                
                   
                let path='/home';
                 this.props.history.push(path);
                
      
              }
      
              else
              {
                  alert("error logging in");
              }
            }) 
            }
  
  handleName (event){
    this.setState({
      username: event.target.value
    });
    console.log(this.state.username);
  }
  handlePassword(event) {
    this.setState({
      password: event.target.value
    });
    console.log(this.state.password);
  }

  handleSubmit = event => {
    event.preventDefault();
  }


  render() {
    return (
      
        <div>
<MDBView src="https://mdbootstrap.com/img/Photos/Others/img%20(50).jpg" >
            

            <MDBMask overlay="indigo-slight" className="flex-center flex-column text-white text-center">
            <MDBContainer>
            <br></br><br></br><br></br>
           <h1 className="title"><strong> Welcome to Standard Chartered Retail Banking </strong> </h1>
                
            <MDBRow style={{marginTop:"3%"}}>
        <MDBCol md="4"></MDBCol>
        <MDBCol md="4">
         
        
          <MDBCard>
            <MDBCardBody>
            <form onSubmit={this.handleSubmit} method="post">

              <MDBCardHeader className="form-header deep-blue-gradient rounded">
                <h3 className="my-3">
                  <MDBIcon icon="lock" /> Login:
                </h3>
              </MDBCardHeader>
              <br></br>
              <label
                htmlFor="defaultFormEmailEx"
                className="black-text font-weight-light"
                
              >
                Your User id
              </label>
              <input
                type="text"
                id="defaultFormEmailEx"
                className="form-control" pattern="([0-9]){7,}" maxLength="7"
                value={this.state.username}
                onChange={(e)=>this.handleName(e)}
  
              />

              <label
                htmlFor="defaultFormPasswordEx"
                className="black-text font-weight-light"
              >
                Your password
              </label>
              <input
                type="password"
                id="defaultFormPasswordEx"
                className="form-control"
                value={this.state.password}
                onChange={(e)=>this.handlePassword(e)}
  
              />

              <div className="text-center mt-4">
                <MDBBtn color="indigo" className="mb-3" onClick={()=>this.validateForm()}
            type="submit"
>
                  Login
                </MDBBtn>

               
              </div>
              </form>

              <MDBModalFooter>
                <div className="font-weight-light">
                  <p style={{color:"black"}}>Not a member? Sign Up</p>
                  <p style={{color:"black"}}>Forgot Password?</p>
                </div>
              </MDBModalFooter>
            </MDBCardBody>
          </MDBCard>
        </MDBCol>
 
        
        
        <MDBCol md="4"></MDBCol>
      </MDBRow>
      
       
    
    </MDBContainer>
    
            </MDBMask>
            
          </MDBView>
      
        </div>
   
    );
  }
}

export default LoginPage;