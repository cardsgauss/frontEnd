import React from 'react';
import axios from 'axios';
import Editing from './editInfo';
import NavbarPage from './newnav';
class List extends React.Component {
constructor(props){
    super(props);
    this.state={...Editing.obj};
    console.log(this.state);
    //this.temp = this.state;
 }
handleName=(event)=>{
    this.setState({name:event.target.value})
}
handleEmail=(event)=>{
    this.setState({email:event.target.value})
}
    render() {
        // const e=editing.obj;
        // console.log(e);
        const {onSubmit} = this.props;
        return (
        <div>
            <NavbarPage></NavbarPage>
            <div style={{backgroundImage:"url("+"https://mdbootstrap.com/img/Photos/Others/img%20(50).jpg" +")",backgroundSize:'cover'}}>
        <div className="row">

    <div className="col-sm-8 col-sm-offset-2">
        <h1 style={{alignContent: 'center', textAlign: 'center'}}>Edit Application</h1>
        <div className="panel panel-default">
            <div className="panel-heading">
                <h5 className="text-center" style={{fontWeight:'600'}} > Form Creation</h5>
            </div>
            <div className="panel-body">

                <form className="form-horizontal" >
                    <div className="form-group">
                        <label className="control-label col-sm-4" >Name:</label>
                        <div className="col-sm-4">
                            <input type="text" className="form-control" value={this.state.name} onChange={(e)=>this.handleName(e)} id="name"  placeholder="Enter name" name="name"
                               required/>
                        </div>
                    </div>
                    <div className="form-group">
                            <label className="control-label col-sm-4" >Email:</label>
                            <div className="col-sm-4">
                                <input type="email" className="form-control" value={this.state.email} onChange={(e)=>this.handleEmail(e)} id="email" placeholder="Enter email" name="email"
                                    required/>
                            </div>
                        </div>
                        <div className="form-group">
                                <label className="control-label col-sm-4" >Mobile No:</label>
                                <div className="col-sm-4">
                                    <input type="tel" className="form-control" id="phone" value={this.state.mobile} placeholder="Enter mobile no" name="phone"
                                        required maxlength="10" />
                                </div>
                            </div>
                    <div className="form-group">
                        <label className="control-label col-sm-4" >Product:</label>
                        <div className="col-sm-4">
                            
                                    <select className="form-control" id="product">
                                        
                                        <option>Silver</option>
                                        <option>Gold</option>
                                        <option>Platinum</option>

                                    </select>
                                
                        </div>
                    </div>
                    <div className="form-group">
                        <label className="control-label col-sm-4" >Aadhaar Card No:</label>
                        <div className="col-sm-4">
                            <input type="tel" className="form-control" id="aadhaar" value={this.state.aadhaar} placeholder="Enter aadhaar no" name="aadhaar"
                                required maxlength="12"/>
                        </div>
                        <div className="col-sm-4">
                                <input type="file"  id="ac" placeholder="Attachment" name="ac"
                                    required/>
                            </div>
                       
                    </div>
                    <div className="form-group">
                        <label className="control-label col-sm-4" >Address proof:</label>
                        <div className="col-sm-4">
                            <input type="text" className="form-control" id="ap" value={this.state.address} placeholder="Enter Id proof no" name="ap"
                                required/>
                            </div>
                                <div className="col-sm-4">
                                        <input type="file"  id="address"  name="address"
                                            required/>
                                    </div>

                       
                       
                    </div>
                    <div className="form-group">
                        <label className="control-label col-sm-4" >Income proof:</label>
                        <div className="col-sm-4">
                            <input type="text" className="form-control" id="ip" value={this.state.income} placeholder="Enter pan card no" name="ip"
                                required/>
                        </div>
                        <div className="col-sm-4">
                                <input type="file"  id="pan" name="pan"
                                    required/>
                            </div>
                       
                    </div>
                    <div className="form-group">
                        <label className="control-label col-sm-4" >Profile</label>
                        <div className="col-sm-4">
                            <div className="form-group">
                                <div className="col-sm-12">
                                    <select className="form-control" id="sel2">
                                        <option>New</option>
                                        <option>Existing</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>

                    </div>

                   

                    <div className="but-al">

                        <div className="form-group">
                            <div className=" col-sm-8 col-sm-offset-6">
                                <button  type="button" className="btn btn-success"  onClick={(e) => this.onboard(e)}>Submit</button>
                                
                                <button type="reset" className="btn btn-default">Reset</button>
                            </div>
                           
                                    
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
</div>
        </div>
        
);
    }
}

export default List;