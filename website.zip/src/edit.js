import React from 'react';
import axios from 'axios';
import Editing from './editInfo';
import { Container } from '@material-ui/core';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
class List extends React.Component {
constructor(props){
    super(props);
    this.state={...Editing.obj};
    console.log(this.state);
    //this.temp = this.state;
 }
handleName=(event)=>{
    this.setState({name:event.target.value})
}
    render() {
        // const e=editing.obj;
        // console.log(e);
        const {onSubmit} = this.props;
        return (
            <Paper style={{ marginLeft: "15%", marginRight: "15%", marginTop: "7%" }}>
            <Container maxWidth="xl" style={{ marginTop: "5%" }}>
                <Grid>
                    <form onSubmit={this.onSubmit} >

                        <div className="row">

                            <div className="col-sm-12" >
                                <h2 style={{ alignContent: 'center', textAlign: 'center', marginTop: "4%" }}>Edit Application</h2>

                                <br></br>
                                <h5 className="text-center" style={{ fontWeight: '600' }} > Form Creation</h5>
                                <br></br>



                                <form className="form-horizontal" className="col-sm-12" style={{ paddingLeft: "25%" }}  >
                                    <div className="form-group">
                                        <label className="control-label col-sm-8" >Name:</label>
                                        <div className="col-sm-8">
                                            <input type="text" className="form-control" id="name" value={this.state.name} onChange={(e)=>this.handleName(e)} 
                                                placeholder="Enter name"
                                                required />
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <label className="control-label col-sm-8" >Email:</label>
                                        <div className="col-sm-8">
                                            <input type="email" className="form-control" id="email" placeholder="Enter email" name="email" value={this.state.email}
                                                />
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <label className="control-label col-sm-8" >Mobile No:</label>
                                        <div className="col-sm-8">
                                            <input type="tel" className="form-control" id="phone" placeholder="Enter mobile no" name="phone" value={this.state.mobile} 
                                                 required maxlength="10"/>
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <label className="control-label col-sm-8" >Product:</label>
                                        <div className="col-sm-8">

                                            <select className="form-control" id="product" onChange={this.handleProduct} value={this.product}>

                                                <option>Silver</option>
                                                <option>Gold</option>
                                                <option>Platinum</option>

                                            </select>

                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <label className="control-label col-sm-8" >Aadhaar Card No:</label>
                                        <div className="col-sm-8">
                                            <input type="tel" className="form-control" id="aadhaar"value={this.state.aadhaar} placeholder="Enter aadhaar no" name="aadhaar"
                            required maxlength="12"
                                            />
                                        </div>
                                        <div className="col-sm-8">
                                            <input type="file" id="ac" placeholder="Attachment" name="ac"
                                            />
                                        </div>

                                    </div>
                                    <div className="form-group">
                                        <label className="control-label col-sm-8" >Address proof:</label>
                                        <div className="col-sm-8">
                                            <input type="text" className="form-control" 
                                             value={this.state.address} placeholder="Enter Id proof no" name="ap"
                                             required />
                                        </div>
                                        <div className="col-sm-8">
                                            <input type="file" id="address" name="address"
                                            />
                                        </div>



                                    </div>
                                    <div className="form-group">
                                        <label className="control-label col-sm-8" >Income proof:</label>
                                        <div className="col-sm-8">
                                            <input type="text" className="form-control" id="ip" placeholder="Enter pan card no" name="ip" value={this.state.income} placeholder="Enter pan card no" name="ip" required />
                                        </div>
                                        <div className="col-sm-8">
                                            <input type="file" id="pan" name="pan"
                                            />
                                        </div>

                                    </div>
                                    <div className="form-group">
                                        <label className="control-label col-sm-8" >Profile</label>
                                        <div className="col-sm-8">
                                            <div className="form-group">
                                                <div className="col-sm-12">
                                                    <select className="form-control" onChange={this.handleProfile} value={this.profile} id="sel2">
                                                        <option>New</option>
                                                        <option>Existing</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>

                                    </div>



                                    <div className="but-al">

                                        <div className="form-group">
                                            <div className=" col-sm-8 col-sm-offset-6">
                                                <button type="submit" className="btn btn-success" onClick={(e) => this.onboard(e)} >Submit</button>
                                                

                                                <button type="reset" className=" col-sm-offset-2" className="btn btn-default">Reset</button>
                                            </div>


                                        </div>
                                    </div>
                                </form>

                            </div>

                        </div>

                    </form>
                </Grid>

            </Container>
        </Paper>

);
    }
}

export default List;



