import React from 'react';
//import './App.css';


class NextGen extends React.Component {
    render() {
        return (
<div style={{textAlign:"center"}}>
    <h1>Welcome to Next Generation Onboarding System</h1>
</div>
           


        );
    }
};
export default NextGen;