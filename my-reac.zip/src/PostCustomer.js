import React from 'react';
import axios from 'axios';
import bg from './bg1.jpeg';
class PostCustomer extends React.Component {
    state={
        customer:[]
    }
    // constructor(props){
    //     super(props);
    //     this.state={
    //         fname:''
    //     };
        
    // }
    handleName = (e) => {
        /*
          Because we named the inputs to match their
          corresponding values in state, it's
          super easy to update the state
        */
        this.setState({ name: e.target.value });
      }
      handleEmail = (e) => {
        this.setState({ email: e.target.value });
    }
    handleMobile = (e) => {
        this.setState({ mobile: e.target.value });
    }
    handleProduct = (e) => {
        this.setState({ product: e.target.value });
    }
    handleAadhaar = (e) => {
        this.setState({ aadhaar: e.target.value });
    }
    handleAp = (e) => {
        this.setState({ address: e.target.value });
    }
    handleIncome = (e) => {
        this.setState({ income: e.target.value });
    }
    handleProfile = (e) => {
        this.setState({ profile: e.target.value });
    }
      onSubmit = (e) => {
       // const { fname } = this.state;
this.newCustomer={  name:this.state.name,
                    email:this.state.email,
                    mobile:this.state.mobile,
                    product:this.state.product,
                    aadhaar:this.state.aadhaar,
                    address:this.state.address,
                    income:this.state.income,
                    profile:this.state.profile
}
        e.preventDefault();

        axios.post(`http://localhost:9000/customer/add`,             // email: document.getElementById('email').value,
            
          this.newCustomer
            //name: document.getElementById('name').value,
        //     mobile: document.getElementById('phone').value,
        //    product: document.getElementById('product').value,
        //     aadhaar: document.getElementById('aadhaar').value,
        //     address: document.getElementById('ap').value,
        //     income: document.getElementById('ip').value,
        //     profile: document.getElementById('sel2').value
            
        )
          .then(res => {
              
            if(res.data > 0) {
                alert("Customer Created Successfully");
                {this.setState({[res.data]:this.customer})};
                let path = '/';
    this.props.history.push(path);
            } else {
                alert("Error creating Customer");
            }
          })

    }

    render() {
        const { fname } = this.state;
         //const {onSubmit} = this.props;
        return (
            <div style={{backgroundImage:"url("+bg +")",backgroundSize:'cover'}}>
        <form onSubmit={this.onSubmit} >
        <div >
        <div className="row">

    <div className="col-sm-8 col-sm-offset-2">
        <h1 style={{alignContent: 'center', textAlign: 'center'}}>New User Application</h1>
        <div className="panel panel-default">
            <div className="panel-heading">
                <h5 className="text-center" style={{fontWeight:'600'}} > Form Creation</h5>
            </div>
            <div className="panel-body">

                <form className="form-horizontal" >
                    <div className="form-group">
                        <label className="control-label col-sm-4" >Name:</label>
                        <div className="col-sm-4">
                            <input type="text" className="form-control" id="name" onChange={this.handleName} value={this.fname}
               placeholder="Enter name" 
                                required/>
                        </div>
                    </div>
                    <div className="form-group">
                            <label className="control-label col-sm-4" >Email:</label>
                            <div className="col-sm-4">
                                <input type="email" className="form-control" id="email" placeholder="Enter email" name="email"
                                 onChange={this.handleEmail} value={this.email}   />
                            </div>
                        </div>
                        <div className="form-group">
                                <label className="control-label col-sm-4" >Mobile No:</label>
                                <div className="col-sm-4">
                                    <input type="tel" className="form-control" id="phone" placeholder="Enter mobile no" name="phone"
                                      onChange={this.handleMobile} value={this.mobile}    />
                                </div>
                            </div>
                    <div className="form-group">
                        <label className="control-label col-sm-4" >Product:</label>
                        <div className="col-sm-4">
                            
                                    <select className="form-control" id="product" onChange={this.handleProduct} value={this.product}>
                                        <option>Please select Card Type</option>
                                        <option>Silver</option>
                                        <option>Gold</option>
                                        <option>Platinum</option>

                                    </select>
                                
                        </div>
                    </div>
                    <div className="form-group">
                        <label className="control-label col-sm-4" >Aadhaar Card No:</label>
                        <div className="col-sm-4">
                            <input type="tel" className="form-control" id="aadhaar" onChange={this.handleAadhaar} value={this.aadhaar}  placeholder="Enter aadhaar no" name="aadhaar"
                                />
                        </div>
                        <div className="col-sm-4">
                                <input type="file"  id="ac" placeholder="Attachment" name="ac"
                                   />
                            </div>
                       
                    </div>
                    <div className="form-group">
                        <label className="control-label col-sm-4" >Address proof:</label>
                        <div className="col-sm-4">
                            <input type="text" className="form-control" onChange={this.handleAp} value={this.ap} id="ap" placeholder="Enter Id proof no" name="ap"
                                />
                            </div>
                                <div className="col-sm-4">
                                        <input type="file"  id="address"  name="address"
                                            />
                                    </div>

                       
                       
                    </div>
                    <div className="form-group">
                        <label className="control-label col-sm-4" >Income proof:</label>
                        <div className="col-sm-4">
                            <input type="text" className="form-control" id="ip" placeholder="Enter pan card no" name="ip"
                              onChange={this.handleIncome} value={this.income}  />
                        </div>
                        <div className="col-sm-4">
                                <input type="file"  id="pan" name="pan"
                                    />
                            </div>
                       
                    </div>
                    <div className="form-group">
                        <label className="control-label col-sm-4" >Profile</label>
                        <div className="col-sm-4">
                            <div className="form-group">
                                <div className="col-sm-12">
                                    <select className="form-control" onChange={this.handleProfile} value={this.profile} id="sel2">
                                        <option>Please select Profile Type</option>
                                        <option>New</option>
                                        <option>Existing</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>

                    </div>

                   

                    <div className="but-al">

                        <div className="form-group">
                            <div className=" col-sm-8 col-sm-offset-6">
                                <button  type="submit" className="btn btn-success"  >Submit</button>
                                
                                <button type="reset" className="btn btn-default">Reset</button>
                            </div>
                           
                                    
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
</div>
</form>
</div>
);
    }
}

export default PostCustomer;