import React from 'react';
import NavbarPage from './newnav';


class CustomerForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            id: '',
            lastName: '',
            email: ''
        };
       

    }
   
  
    render() {
        return (
            <div>
                <NavbarPage/>
                <div style={{backgroundImage:"url("+"https://mdbootstrap.com/img/Photos/Others/img%20(50).jpg" +")",backgroundSize:'cover'}}>
                <h3 style={{textAlign:'center'}}>Add Customer</h3>
                <hr />
                <form onSubmit={this.handleSubmit} className="ui form">
                    <div className="form-group">
                        <label>Id</label>
                        <input
                            type="text"
                            name="firstName"
                            className="form-control"
                            value={this.state.firstName}
                            
                        />
                    </div>

                    <div className="form-group">
                        <label>First Name</label>
                        <input
                            type="text"
                            name="lastName"
                            className="form-control"
                        />
                    </div>
                    <div className="form-group">
                        <label>Last Name</label>
                        <input
                            type="text"
                            name="email"
                            className="form-control"
                        />
                    </div>
                    <button type="submit" className="btn btn-primary">
                        Add Customer
                  </button>
                  <button type="button" className="btn btn-primary">
                        List
                  </button>
                </form>
            </div>
            </div>
            
        );
    }

}
export default CustomerForm;