import React, { Component } from 'react';
import './App.css';
import ReactTable from "react-table";
import "react-table/react-table.css";
//import MaterialTable from 'material-table';
import { style } from '@material-ui/system';
import PostCustomer from './PostCustomer';
import {BrowserRouter as Router,Switch,Link,Route} from "react-router-dom";
import axios from 'axios';
import List from './list';
import editing from './editInfo';
import { Paper } from '@material-ui/core';
import { Container } from '@material-ui/core';
import { Grid } from '@material-ui/core';
import bg from './bg1.jpeg';
import NavbarPage from './newnav';
class Table extends Component {
  constructor(props) {
    super(props);
    this.state = {
      posts: []
      
    }

  }

  componentDidMount() {
    const url = "http://localhost:9000/app/";
    fetch(url, {
      method: "GET"
    }).then(reponse => reponse.json()).then(posts => {
      this.setState({ posts, posts })
    })
  }
//   deleteRow(id){
//       console.log("id",id)
//   }
 deleteRow = (id) => {
     console.log(id)
    
     axios.delete("http://localhost:9000/app/delete/"+encodeURIComponent(id))
    .then(
      res => {

        if (res.data > 0) {

        /*axios.get("http://localhost:9122/customer/")
        .then((res) => {
            console.log(res.data);
            this.setState({
                posts: res.data
            })
        })*/

       alert("Deleted Successfully");
       let path = '/';
        this.props.history.push(path);

      }
      else {
        alert("Error creating Customer");
    }
  }
        //this.forceUpdate()
         /*fetch("http://localhost:9122/customer/", {
            method: "GET"
          }).then(reponse => reponse.json()).then(posts => {
            this.setState({ posts, posts })
          })*/
       
     );
}
editRow=(id)=>{
    console.log(id);
   
    axios.get("http://localhost:9000/customer/"+encodeURIComponent(id))
    .then((res) => {
        //console.log(res.data);
        editing.obj=res.data;
        let path = 'edit';
    this.props.history.push(path);
    });
}
createRow=()=>{
   
    let path = 'form';
    this.props.history.push(path);
    
}
NextPage=(id)=>{
   console.log(id);
   axios.get("http://localhost:9000/customer/"+encodeURIComponent(id))
    .then((res) => {
        //console.log(res.data);
        editing.obj=res.data;
        let path = 'credit';
    this.props.history.push(path);
    });
    
}
  render() {
      
    const columns = [
      {
        Header: "App Id",
        accessor: "appId",
        width:100,maxWidth:100,minWidth:100

      },
      {
        Header: "App Name",
        accessor: "appName"
      },
      {
        Header: "App Status",
        accessor: "status",
        
        
      },
      {
        Header: "App Age",
        accessor: "age"
      }
      ,
      {
        Header: "Handled by Sales User",
        accessor: "handledBy"
      } ,
      {
        Header: "Actions",
        Cell:props=>{
            return(
              
                [
                    
                    <button  className="btn btn-sm " style={{backgroundColor:'#78ADD2',color:'white'}} onClick={()=>{
                        this.editRow(props.original.id);}}>Edit</button>,
        <button className="btn btn-sm btn-success"  style={{marginLeft:10}} onClick={()=>{
            this.NextPage(props.original.id);}}>Next</button>,
                <button type="delete" className="btn btn-sm btn-danger"  style={{marginLeft:10}} onClick={()=>{
                    this.deleteRow(props.original.id);
                }}>Delete</button>
                
                ]
            )
        }
      }
    ]
    return (
      <div>
        <NavbarPage/>
        <div style={{backgroundImage:"url("+"https://mdbootstrap.com/img/Photos/Others/img%20(50).jpg" +")",backgroundSize:'cover'}}>
      <Paper style={{marginTop:"5%"}}>
                <Container maxWidth="xl" style={{marginTop:"10px"}}>
                <Grid>
        <div>
             {/* <ul>
        
        <li>
          <Link to="/list" >EDIT</Link>
        </li>
        <li>
          <Link to="/form" >CREATE</Link>
          
        </li>
      </ul> */}
      <div style={{textAlign:"center",marginTop:'100px'}}>
    <h2 class="title" style={{paddingTop:'20px'}}>Welcome to Next Generation Onboarding System</h2>
</div>
      <ReactTable
     style={{ marginTop: 30}}
        columns={columns}
        
        data={this.state.posts}
       defaultPageSize={5}
        filterable
      >
      </ReactTable>
      {/* <button className="btn btn-success" onClick={()=>{
                        this.createRow();}} style={{marginLeft:500,marginTop:10}}> Create</button> */}
      </div>
      </Grid>
      </Container>
      </Paper>
      </div>
      </div>
      
    );
  }
}

export default Table;
