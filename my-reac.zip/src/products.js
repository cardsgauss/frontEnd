import React, { Component } from 'react';
import './App.css';
import ReactTable from "react-table";
import "react-table/react-table.css";
import MaterialTable from 'material-table';
import { style } from '@material-ui/system';
import PostCustomer from './PostCustomer';
import {BrowserRouter as Router,Switch,Link,Route} from "react-router-dom";
import axios from 'axios';
import List from './list';
import editing from './editInfo';
import { Paper } from '@material-ui/core';
import { Container } from '@material-ui/core';
import { Grid } from '@material-ui/core';
import bg from './bg1.jpeg';
class Table extends Component {
  constructor(props) {
    super(props);
    this.state = {
      posts: []
      
    }

  }

  componentDidMount() {
    const url = "http://localhost:9000/product/";
    fetch(url, {
      method: "GET"
    }).then(reponse => reponse.json()).then(posts => {
      this.setState({ posts, posts })
    })
  }

    

  render() {
      
    const columns = [
      {
        Header: "Customer id",
        accessor: "id",
        width:100,maxWidth:100,minWidth:100

      },
      {
        Header: "Customer name",
        accessor: "name"
      },
      {
        Header: "Product",
        accessor: "prod_type",
        
        
      }
                
    ]
    return (
      <div style={{backgroundImage:"url("+bg +")",backgroundSize:'cover'}}>
      <Paper style={{marginTop:"5%"}}>
                <Container maxWidth="xl" style={{marginTop:"10px"}}>
                <Grid>
        <div>
             {/* <ul>
        
        <li>
          <Link to="/list" >EDIT</Link>
        </li>
        <li>
          <Link to="/form" >CREATE</Link>
          
        </li>
      </ul> */}
      <div style={{textAlign:"center",marginTop:'100px'}}>
    <h2 class="title" style={{paddingTop:'20px'}}>Welcome to Next Generation Onboarding System</h2>
</div>
      <ReactTable
     style={{ marginTop: 30}}
        columns={columns}
        
        data={this.state.posts}
       defaultPageSize={5}
        filterable
      >
      </ReactTable>
      {/* <button className="btn btn-success" onClick={()=>{
                        this.createRow();}} style={{marginLeft:500,marginTop:10}}> Create</button> */}
      </div>
      </Grid>
      </Container>
      </Paper>
      </div>
    );
  }
}

export default Table;
