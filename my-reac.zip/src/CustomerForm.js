import React from 'react';

class CustomerForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            id: '',
            lastName: '',
            email: ''
        };
       

    }
   
  
    render() {
        return (
            <div>
                <h3 style={{textAlign:'center'}}>Add Customer</h3>
                <hr />
                <form onSubmit={this.handleSubmit} className="ui form">
                    <div className="form-group">
                        <label>Id</label>
                        <input
                            type="text"
                            name="firstName"
                            className="form-control"
                            value={this.state.firstName}
                            
                        />
                    </div>

                    <div className="form-group">
                        <label>First Name</label>
                        <input
                            type="text"
                            name="lastName"
                            className="form-control"
                        />
                    </div>
                    <div className="form-group">
                        <label>Last Name</label>
                        <input
                            type="text"
                            name="email"
                            className="form-control"
                        />
                    </div>
                    <button type="submit" className="btn btn-primary">
                        Add Customer
                  </button>
                  <button type="button" className="btn btn-primary">
                        List
                  </button>
                </form>
            </div>
        );
    }

}
export default CustomerForm;