import React from "react";
import { MDBCol, MDBContainer, MDBRow, MDBFooter } from "mdbreact";

const FooterPage = () => {
  return (
    <MDBFooter color="blue" className="font-small pt-4 " style={{paddingTop: 0}} >
      <MDBContainer fluid className="text-center text-md-left">
        <MDBRow>
          <MDBCol md="6">
            <h5 className="title"><strong>About</strong></h5>
            <p>
              The project of generating the Credit Card process has been completed by GAUSS-Cards team. 
            </p>
          </MDBCol>
          <MDBCol md="3">
            <h5 className="title" style={{marginLeft:'12%'}}><strong>Useful Links</strong></h5>
            <ul>
              <li className="list-unstyled">
                <a href="#!">Your Profile</a>
              </li>
              <li className="list-unstyled">
                <a href="#!">Contact Us</a>
              </li>
              <li className="list-unstyled">
                <a href="#!">Services</a>
              </li>
              <li className="list-unstyled">
                <a href="#!">Help</a>
              </li>
            </ul>
          </MDBCol>
          <MDBCol md="3">
            <h5 className="title" style={{marginLeft:'12%'}}><strong>Products</strong></h5>
            <ul>
              <li className="list-unstyled">
                <a href="#!">Silver</a>
              </li>
              <li className="list-unstyled">
                <a href="#!">Gold</a>
              </li>
              <li className="list-unstyled">
                <a href="#!">Platinum</a>
              </li>
              <li className="list-unstyled">
                <a href="#!">Titanium</a>
              </li>
            </ul>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
      <div className="footer-copyright text-center py-3">
        <MDBContainer fluid>
          &copy; {new Date().getFullYear()} Copyright: <a href="https://www.MDBootstrap.com"> StandardChartered.com </a>
        </MDBContainer>
      </div>
    </MDBFooter>
  );
}

export default FooterPage;