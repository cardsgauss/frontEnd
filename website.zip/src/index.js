import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
//import Cards from './home'
import Navbar from './navbar';
//import CreditScore from './creditscore'
//import PostCustomer from './appform.js'
//import SimpleCard from './new'
//import NameForm from './form';
//import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';




ReactDOM.render(< Navbar/>, document.getElementById('root1'));



ReactDOM.render(< App/>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
