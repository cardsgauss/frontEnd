import React, {Component} from 'react';
import PopPop from 'react-poppop';
import axios from 'axios';
import Editing from './editInfo';
import NavbarPage from './newnav';
 class Popup extends React.Component {
  constructor(props) {
    super(props);
  this.state={show: true}
  }

  
handleAadhaar=(e)=>{
  this.setState({ aadhaar: e.target.value });
}
handleVerify=(e)=>{
  
    this.aadhaar= this.state.aadhaar;
    e.preventDefault();
  axios.get("http://localhost:9000/customer/aadhaar/"+encodeURIComponent(this.aadhaar))
  .then((res) => {
      //console.log(res.data);
      //editing.obj=res.data;
     // alert(res.data);
     if(res.data>0)
     {
     axios.get("http://localhost:9000/customer/"+encodeURIComponent(res.data))
     .then((res1) => {
         //console.log(res.data);
         Editing.obj=res1.data;
         let path = 'existing';
     this.props.history.push(path);
     });
    }
    else
    {
      let path = 'form';
     this.props.history.push(path);
    }
  //  let path = 'edit';
  //   this.props.history.push(path);
  });

}
toggleShow = show => {
  this.setState({show});
}

  render() {
    const {show} = this.state;
    return (

    <div>
      <NavbarPage></NavbarPage>
       <div style={{backgroundImage:"url("+"https://mdbootstrap.com/img/Photos/Others/img%20(50).jpg" +")",backgroundSize:'cover'}}>
        <PopPop position="centerCenter"
                open={show}
                closeOnEsc={true}
                onClose={() => this.toggleShow(false)}
                closeOnOverlay={true}>
        <form style={{textAlign:"center"}} onSubmit={this.handleVerify}>
        

          <h3 style={{textAlign:"center"}}> Existing Customer Verfication</h3>
          <br></br>
         
          <div>
              Enter your Aadhar Number:  <span>&nbsp;&nbsp;</span>
              <input type= "text" value={this.aadhaar} onChange={this.handleAadhaar}></input>              
              
          </div>
           
          <div>
          <br></br>
          <button  className="btn btn-default" id="button" >Verify</button>
          </div>
         
          </form>
       </PopPop>
       
      </div>
    </div>
     
    )
  }
}

export default Popup;

