import React, { Component } from "react";
import { BrowserRouter as Router} from 'react-router-dom';
import {
MDBNavbar, MDBNavbarBrand, MDBNavbarNav, MDBNavItem, MDBNavLink, MDBNavbarToggler, MDBCollapse, MDBFormInline,
MDBDropdown, MDBDropdownToggle, MDBDropdownMenu, MDBDropdownItem, MDBIcon
} from "mdbreact";
import Editing from './editInfo';
class NavbarPage extends Component {
  constructor(props){
    super(props);
    this.state={...Editing.obj}
    //localStorage.setItem("id",this.state.username)
  }
 
state = {
  isOpen: false
};

toggleCollapse = () => {
  this.setState({ isOpen: !this.state.isOpen });
}

render() {
 
  return (
      <Router> 
          <MDBNavbar color="indigo" dark expand="md">
          
      <MDBNavbarBrand>
        <strong className="white-text">Standard Chartered</strong>
      </MDBNavbarBrand>
      <MDBNavbarToggler onClick={this.toggleCollapse} />
      <MDBCollapse id="navbarCollapse3" isOpen={this.state.isOpen} navbar>
        <MDBNavbarNav left>
          <MDBNavItem active>
            <a style={{color:"white"}} href="/home">Home</a>
          </MDBNavItem>
         
        </MDBNavbarNav>
        <MDBNavbarNav right>
          
          <MDBNavItem>
            <MDBDropdown>
              <MDBDropdownToggle nav caret>
                <span className="mr-2">Hello {localStorage.getItem("id")}</span>
              </MDBDropdownToggle>
              <MDBDropdownMenu>
                <MDBDropdownItem href="/">Logout</MDBDropdownItem>
                
              </MDBDropdownMenu>
            </MDBDropdown>
          </MDBNavItem>
          <MDBNavItem>
              
              <MDBIcon icon="user-circle" size="2x"  gradient="purple"/>
          </MDBNavItem>
        </MDBNavbarNav>
      </MDBCollapse>
    </MDBNavbar></Router>
     
    );
  }
}

export default NavbarPage;