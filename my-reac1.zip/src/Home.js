/* import React, { Component } from 'react';

class Home extends Component {
  render() {
    return (
        <div>
          <h2>Home</h2>
        </div>
    );
  }
}

export default Home; */

import React from 'react';

import CardMedia from '@material-ui/core/CardMedia';
import Card from '@material-ui/core/Card';

import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Container from '@material-ui/core/Container';
import Typography from '@material-ui/core/Typography';

import Grid from '@material-ui/core/Grid';

import ap from './app.webp';
import ne from './new.webp';
import cus from './cust.jpg';
import p from './P.jpg';
import a from './app.jpg';
import d from './id.png';
import bg from './bg1.jpeg';
import Nav from './nav'

import NavbarPage from './newnav';

const useStyles = makeStyles(theme => ({
    card: {
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        maxWidth: "250px", marginLeft: "10%", marginTop: "10%"
    },
    cardMedia: {
        paddingTop: '66.25%', // 16:9
    },
    cardContent: {
        flexGrow: 1,


    },
    cardGrid: {
        paddingTop: theme.spacing(8),
        paddingBottom: theme.spacing(8),
    },
}));


export default function Home() {
    const classes = useStyles();



    return (


        <div>

            <NavbarPage></NavbarPage>
            <div style={{backgroundImage:"url("+"https://mdbootstrap.com/img/Photos/Others/img%20(50).jpg" +")",backgroundSize:'cover'}}>
                <Container className={classes.cardGrid} maxWidth="md">
                    <Grid container md={12} container spacing={4}>

                        <Grid item md={4}>

                            <Card className={classes.card} >
                                <CardMedia
                                    className={classes.cardMedia}
                                    image={ne}
                                    title="Image title"
                                />
                                <CardContent className={classes.cardContent}>
                                    <Typography gutterBottom variant="h5" component="h2">

                                        Create Application
                            </Typography>
                                    <Typography>
                                        Create a new Credit Card application
                            </Typography>
                                </CardContent>
                                <CardActions>
                                    <Button size="medium" color="primary" href="contact" href="/popup">
                                        View
                            </Button>

                                </CardActions>
                            </Card>
                        </Grid>




                        <Grid item md={4}>

                            <Card className={classes.card} >
                                <CardMedia
                                    className={classes.cardMedia}
                                    image={ap}
                                    title="Image title"
                                />
                                <CardContent className={classes.cardContent}>
                                    <Typography gutterBottom variant="h5" component="h2">
                                        View Application List
                            </Typography>
                                    <Typography>
                                        View and edit Credit Card application status
                            </Typography>
                                </CardContent>
                                <CardActions>
                                    <Button size="medium" color="primary" href="/table">
                                        View
                            </Button>

                                </CardActions>
                            </Card>
                        </Grid>


                        <Grid item md={4}>

                            <Card className={classes.card} >
                                <CardMedia
                                    className={classes.cardMedia}
                                    image={cus}
                                    title="Image title"
                                />
                                <CardContent className={classes.cardContent}>
                                    <Typography gutterBottom variant="h5" component="h2">
                                        View Customer List
                            </Typography>
                                    <Typography>
                                        View existing customer list
                            </Typography>
                                </CardContent>
                                <CardActions>
                                    <Button size="medium" color="primary" href="/customer">
                                        View
                            </Button>

                                </CardActions>
                            </Card>
                        </Grid>



                        <Grid item md={4}>

                            <Card className={classes.card} >
                                <CardMedia
                                    className={classes.cardMedia}
                                    image={p}
                                    title="Image title"
                                />
                                <CardContent className={classes.cardContent}>
                                    <Typography gutterBottom variant="h5" component="h2">
                                        View Product List
                            </Typography>
                                    <Typography>
                                        View generated Credit Cards list
                            </Typography>
                                </CardContent>
                                <CardActions>
                                    <Button size="medium" color="primary" href="/product">
                                        View
                            </Button>

                                </CardActions>
                            </Card>
                        </Grid>


                        <Grid item md={4}>

                            <Card className={classes.card} >
                                <CardMedia
                                    className={classes.cardMedia}
                                    image={a}
                                    title="Image title"
                                />
                                <CardContent className={classes.cardContent}>
                                    <Typography gutterBottom variant="h5" component="h2">
                                        Appeals
                            </Typography>
                                    <Typography>
                                        View appeal requests and status
                            </Typography>
                                </CardContent>
                                <CardActions>
                                    <Button size="medium" color="primary" href="/appealTable">
                                        View
                            </Button>

                                </CardActions>
                            </Card>
                        </Grid>


                        <Grid item md={4}>

                            <Card className={classes.card} >
                                <CardMedia
                                    className={classes.cardMedia}
                                    image={d}
                                    title="Image title"
                                />
                                <CardContent className={classes.cardContent}>
                                    <Typography gutterBottom variant="h5" component="h2">
                                        Document Verification
                            </Typography>
                                    <Typography>
                                        View documents verification status of customer
                            </Typography>
                                </CardContent>
                                <CardActions>
                                    <Button size="medium" color="primary" href="/document">
                                        View
                            </Button>

                                </CardActions>
                            </Card>
                        </Grid>


                    </Grid>

                </Container>
            </div>
        </div>
    );
}
