import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
//import Home from './components/Home';
import About from './components/About';
import Contact from './components/Contact';
import Notfound from './components/notfound'
import PostCustomer from './appform'
import Home from './components/Home';
import List from './edit';
import Atable from './appealform'
class App extends Component {
  render() {
    return (
    <Router>
        <div>
          {/* <h2>Welcome to Standard Chartered Bank</h2>
          <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <ul className="navbar-nav mr-auto">
            <li><Link to={'/'} className="nav-link"> Home </Link></li>
            <li><Link to={'/contact'} className="nav-link">Contact</Link></li>
            <li><Link to={'/about'} className="nav-link">About</Link></li>
          </ul>
          </nav>
          <hr /> */}
          <Switch>
              <Route exact path='/' component={About} />
              <Route path='/contact' component={Contact} />
              <Route path='/home' component={Home} />
              <Route path='/create' component={PostCustomer} />
              <Route path='/edit' component={List} />
              <Route path='/appealform' component={Atable} />


              <Route component={Notfound} />
          </Switch>
        </div>
      </Router>
    );
  }
}

export default App;
